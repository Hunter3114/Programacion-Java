/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviciohospitalario;

import java.util.ArrayList;

/**
 *
 * @author Andres
 */
public class Ingreso {
    private Paciente paciente;
    private String FechaIngreso;
    private String FechaAlta;
    private Servicio ServicioAsignado;
    private int IDservicio;
    private double Precio;

    public String getFechaIngreso() {
        return FechaIngreso;
    }

    public void setFechaIngreso(String FechaIngreso) {
        this.FechaIngreso = FechaIngreso;
    }

    public String getFechaAlta() {
        return FechaAlta;
    }

    public void setFechaAlta(String FechaAlta) {
        this.FechaAlta = FechaAlta;
    }

    public int getIDservicio() {
        return IDservicio;
    }

    public void setIDservicio(int IDservicio) {
        this.IDservicio = IDservicio;
    }

    public double getPrecio() {
        return Precio;
    }

    public void setPrecio(double Precio) {
        this.Precio = Precio;
    }
    
}
