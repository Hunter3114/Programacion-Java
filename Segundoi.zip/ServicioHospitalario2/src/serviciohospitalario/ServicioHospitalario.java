/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviciohospitalario;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Andres
 */
public class ServicioHospitalario {
    private ArrayList<Paciente> pacientes;
    private ArrayList<Farmaco> farmacos;

    public ServicioHospitalario() {
        this.pacientes = new ArrayList<>();
        this.farmacos = new ArrayList<>();
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ServicioHospitalario servicioHospitalario = new ServicioHospitalario();
        Scanner scanner = new Scanner(System.in);

        int opcion;
        do {
            System.out.println("\n Menú Principal ");
            System.out.println("1. Alta de paciente");
            System.out.println("2. Modificar paciente");
            System.out.println("3. Baja de paciente");
            System.out.println("4. Agregar fármaco");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    servicioHospitalario.altaPaciente(scanner);
                break;
                case 2:
                    servicioHospitalario.listarPacientes();
                break;
                case 3:
                    servicioHospitalario.agregarFarmaco(scanner);
                break;
                case 4:
                    servicioHospitalario.listarFarmacos();
                break;
                case 5:
                    System.out.println("Saliendo del programa...");
                break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
                break;
            }
        } while (opcion != 5);

        scanner.close();
    
    }
    
    public void altaPaciente(Scanner scanner) {
        Paciente paciente = new Paciente();

        System.out.println("\n Alta de Paciente ");
        System.out.print("Ingrese el nombre del paciente: ");
        paciente.setNombre(scanner.nextLine());

        System.out.print("Ingrese la edad del paciente: ");
        paciente.setEdad(scanner.nextInt());
        scanner.nextLine(); // Limpiar el buffer

        System.out.print("Ingrese el sexo del paciente (M/F): ");
        char sexo = scanner.nextLine().charAt(0);
        paciente.setSexo(sexo == 'M' || sexo == 'm');

        
        pacientes.add(paciente);
        System.out.println("Paciente agregado con éxito.");
    }

    public void listarPacientes() {
        System.out.println("\n Listado de Pacientes ");
        if (pacientes.isEmpty()) {
            System.out.println("No hay pacientes registrados.");
        } else {
            for (Paciente paciente : pacientes) {
                System.out.println("Nombre: " + paciente.getNombre() + ", Edad: " + paciente.getEdad() + ", Sexo: " + (paciente.isSexo() ? "Masculino" : "Femenino"));
            }
        }
    }

    // Función para agregar fármaco
    public void agregarFarmaco(Scanner scanner) {
        Farmaco farmaco = new Farmaco();

        System.out.println("\n Agregar Fármaco ");
        System.out.print("Ingrese el nombre del fármaco: ");
        farmaco.setNFarmaco(scanner.nextLine());

        // Agregar el fármaco a la lista de fármacos
        farmacos.add(farmaco);
        System.out.println("Fármaco agregado con éxito.");
    }

    // Función para listar fármacos
    public void listarFarmacos() {
        System.out.println("\n Listado de Fármacos ");
        if (farmacos.isEmpty()) {
            System.out.println("No hay fármacos registrados.");
        } else {
            for (Farmaco farmaco : farmacos) {
                System.out.println("Nombre: " + farmaco.getNFarmaco());
            }
        }
    }
}