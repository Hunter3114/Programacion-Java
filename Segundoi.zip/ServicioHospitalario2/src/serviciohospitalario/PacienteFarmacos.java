/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviciohospitalario;

import java.util.ArrayList;

/**
 *
 * @author Andres
 */
public class PacienteFarmacos extends Paciente{
    String Name_Farmaco;
    ArrayList<Farmaco>Farmacos;

    public String getName_Farmaco() {
        return Name_Farmaco;
    }

    public void setName_Farmaco(String Name_Farmaco) {
        this.Name_Farmaco = Name_Farmaco;
    }
    
}
