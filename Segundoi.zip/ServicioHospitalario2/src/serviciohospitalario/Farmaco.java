/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviciohospitalario;

/**
 *
 * @author Andres
 */
public class Farmaco {
    private String NonFarmaco;
    private String Sustancia;
    private int Numero;
    private String Presentacion;
    private double Precio;

    public String getNFarmaco() {
        return NonFarmaco;
    }

    public void setNFarmaco(String NFarmaco) {
        this.NonFarmaco = NFarmaco;
    }

    public String getSustancia() {
        return Sustancia;
    }

    public void setSustancia(String Sustancia) {
        this.Sustancia = Sustancia;
    }

    public int getNumero() {
        return Numero;
    }

    public void setNumero(int Numero) {
        this.Numero = Numero;
    }

    public String getPresentacion() {
        return Presentacion;
    }

    public void setPresentacion(String Presentacion) {
        this.Presentacion = Presentacion;
    }

    public double getPrecio() {
        return Precio;
    }

    public void setPrecio(double Precio) {
        this.Precio = Precio;
    }
    
    
}
