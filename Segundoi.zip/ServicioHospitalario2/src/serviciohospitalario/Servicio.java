/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviciohospitalario;

import java.util.ArrayList;

/**
 *
 * @author Andres
 */
public class Servicio {
    private Doctor doctorEncargado;
    ArrayList<Paciente>PacienteAsignado;
    ArrayList<Farmaco>FarmacoUtilizado;
    private double Costos;

    public double getCostos() {
        return Costos;
    }

    public void setCostos(double Costos) {
        this.Costos = Costos;
    }
    
}
