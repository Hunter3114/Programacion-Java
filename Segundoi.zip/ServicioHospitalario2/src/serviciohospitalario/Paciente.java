/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviciohospitalario;

import java.util.ArrayList;

/**
 *
 * @author Andres
 */
public class Paciente {
    private String Nombre;
    private int Edad;
    private boolean Sexo;
    private ArrayList<Farmaco>farmacos;
    
    public Paciente(){
        this.farmacos = new ArrayList<>();
    }
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

    public boolean isSexo() {
        return Sexo;
    }

    public void setSexo(boolean Sexo) {
        this.Sexo = Sexo;
    }
    
    public void AgregarFarmaco(Farmaco farmaco){
        this.farmacos.add(farmaco);
    }
    
    public void eliminarFarmaco(Farmaco farmaco){
        this.farmacos.remove(farmaco);
    }
}
