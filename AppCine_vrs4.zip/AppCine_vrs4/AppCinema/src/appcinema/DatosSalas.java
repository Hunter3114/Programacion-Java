/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appcinema;

import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Usuario
 */
public class DatosSalas {
private static DatosSalas instancia;
    private ArrayList<Sala>listaSalas;
    private DefaultTableModel modeloTabla;
    
    public DatosSalas(ArrayList<Sala>listaSalas,DefaultTableModel modeloTabla){
        this.listaSalas=listaSalas;
        this.modeloTabla=modeloTabla;
    }
    
    public static DatosSalas getInstancia(){
        return instancia;
    }
    
    public static void setInstancia(DatosSalas instancia){
        DatosSalas.instancia=instancia;
    }
    
    public ArrayList<Sala> getListaSalas(){
        return listaSalas;
    }
    
    public void setListaSalas(ArrayList<Sala>listaFunciones){
        this.listaSalas=listaSalas;
    }
    
    public DefaultTableModel getModeloTabla(){
        return modeloTabla;
    }
    
    public void setModeloTabla(DefaultTableModel modeloTabla){
        this.modeloTabla=modeloTabla;
    }
    
    private DatosSalas(){
        listaSalas=new ArrayList<>();
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Fila");
        modeloTabla.addColumn("Columna");
        modeloTabla.addColumn("TipoSala");        
    }
    
    public static DatosSalas obtenerInstancia(){
        if(instancia == null){
            instancia =new DatosSalas();
        }
        return instancia;
    }
    
    public ArrayList<Sala> obtenerListaFunciones(){
        return listaSalas;
    }
    
    public DefaultTableModel obtenerModeloTabla(){
        return modeloTabla;
    }
    
    public void agregarSala(Sala sala){
        listaSalas.add(sala);
        Object[]datos={sala.getFila(),sala.getColumna(),sala.getTipoSala()};
        modeloTabla.addRow(datos);
    }
    
}

    
