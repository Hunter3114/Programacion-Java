/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appcinema;

import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Usuario
 */
public class DatosFunciones {
    private static DatosFunciones instancia;
    private ArrayList<Funcion>listaFunciones;
    private DefaultTableModel modeloTabla;
    
    public DatosFunciones(ArrayList<Funcion>listaFunciones,DefaultTableModel modeloTabla){
        this.listaFunciones=listaFunciones;
        this.modeloTabla=modeloTabla;
    }
    
    public static DatosFunciones getInstancia(){
        return instancia;
    }
    
    public static void setInstancia(DatosFunciones instancia){
        DatosFunciones.instancia=instancia;
    }
    
    public ArrayList<Funcion> getListaFunciones(){
        return listaFunciones;
    }
    
    public void setListaFunciones(ArrayList<Funcion>listaFunciones){
        this.listaFunciones=listaFunciones;
    }
    
    public DefaultTableModel getModeloTabla(){
        return modeloTabla;
    }
    
    public void setModeloTabla(DefaultTableModel modeloTabla){
        this.modeloTabla=modeloTabla;
    }
    
    private DatosFunciones(){
        listaFunciones=new ArrayList<>();
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Fecha");
        modeloTabla.addColumn("Hora");
        modeloTabla.addColumn("Sala");
        modeloTabla.addColumn("Pelicula");        
    }
    
    public static DatosFunciones obtenerInstancia(){
        if(instancia == null){
            instancia =new DatosFunciones();
        }
        return instancia;
    }
    
    public ArrayList<Funcion> obtenerListaFunciones(){
        return listaFunciones;
    }
    
    public DefaultTableModel obtenerModeloTabla(){
        return modeloTabla;
    }
    
    public void agregarFuncion(Funcion funcion){
        listaFunciones.add(funcion);
        Object[]datos={funcion.getFecha(),funcion.getHora(),funcion.getSala(),funcion.getPelicula()};
        modeloTabla.addRow(datos);
    }
    
}
