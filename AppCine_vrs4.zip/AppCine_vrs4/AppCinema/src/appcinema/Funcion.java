/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appcinema;

/**
 *
 * @author Usuario
 */
public class Funcion {
    private String Fecha;
    private String Hora;
    private String Sala;
    private String Pelicula;
    
    public String getFecha(){
        return Fecha;
    }
    public void setFecha(String Fecha){
        this.Fecha=Fecha;
    }
    
    public String getHora(){
        return Hora;
    }
    public void setHora(String Hora){
        this.Hora=Hora;
    }
    
    public String  getSala(){
        return Sala;
    }
    public void setSala(String Sala){
        this.Sala=Sala;
    }
    
    public String getPelicula(){
        return Pelicula;
    }
    public void setPelicula(String Pelicula){
        this.Pelicula=Pelicula;
    }
}
