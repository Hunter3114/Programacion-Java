/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appcinema;

import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Hunter
 */
public class DatosPeliculas {
    private static DatosPeliculas instancia;
    private ArrayList<Peliculas> listaPeliculas;
    private DefaultTableModel modeloTabla;

    public DatosPeliculas(ArrayList<Peliculas> listaPeliculas, DefaultTableModel modeloTabla) {
        this.listaPeliculas = listaPeliculas;
        this.modeloTabla = modeloTabla;
    }
    
    
    
    public static DatosPeliculas getInstancia() {
        return instancia;
    }

    public static void setInstancia(DatosPeliculas instancia) {
        DatosPeliculas.instancia = instancia;
    }

    public ArrayList<Peliculas> getListaPeliculas() {
        return listaPeliculas;
    }

    public void setListaPeliculas(ArrayList<Peliculas> listaPeliculas) {
        this.listaPeliculas = listaPeliculas;
    }

    public DefaultTableModel getModeloTabla() {
        return modeloTabla;
    }

    public void setModeloTabla(DefaultTableModel modeloTabla) {
        this.modeloTabla = modeloTabla;
    }
    
    private DatosPeliculas() {
        listaPeliculas = new ArrayList<>();
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Descripción");
        modeloTabla.addColumn("Clasificación");
    }

    public static DatosPeliculas obtenerInstancia() {
        if (instancia == null) {
            instancia = new DatosPeliculas();
        }
        return instancia;
    }

    public ArrayList<Peliculas> obtenerListaPeliculas() {
        return listaPeliculas;
    }

    public DefaultTableModel obtenerModeloTabla() {
        return modeloTabla;
    }

    public void agregarPelicula(Peliculas pelicula) {
        listaPeliculas.add(pelicula);
        Object[] datos = { pelicula.getNombre(), pelicula.getDescripción(), pelicula.getClasificación() };
        modeloTabla.addRow(datos);
    }
    
}
