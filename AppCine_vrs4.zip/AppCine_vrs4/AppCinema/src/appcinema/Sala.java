/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appcinema;

/**
 *
 * @author Usuario
 */
public class Sala {
    private String Fila;
    private String Columna;
    private String TipoSala;

    public String getFila() {
        return Fila;
    }

    public void setFila(String Fila) {
        this.Fila = Fila;
    }

    public String getColumna() {
        return Columna;
    }

    public void setColumna(String Columna) {
        this.Columna = Columna;
    }

    public String getTipoSala() {
        return TipoSala;
    }

    public void setTipoSala(String TipoSala) {
        this.TipoSala = TipoSala;
    }
    
}
