/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appcinema;

import java.io.Serializable;

/**
 *
 * @author Israel Cianca
 */
public class Peliculas implements Serializable{
    private String Nombre;
    private String Descripción;
    private String Clasificación;    
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDescripción() {
        return Descripción;
    }

    public void setDescripción(String Descripción) {
        this.Descripción = Descripción;
    }

    public String getClasificación() {
        return Clasificación;
    }

    public void setClasificación(String Clasificación) {
        this.Clasificación = Clasificación;
    }

    
}
